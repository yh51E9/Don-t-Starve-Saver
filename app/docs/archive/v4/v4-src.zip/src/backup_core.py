# -*- coding: utf-8 -*-
"""backup_core.py —— 备份/恢复/清理/统计的全部业务逻辑。

这一层完全不碰界面，也不假设自己在 Windows 上跑（除了 is_game_running）。
想单独测试某个函数，直接 import 这个文件就行。

备份目录结构：
    backups/slot_<槽位ID>/<时间戳>[_auto|_pre]/   ← 一个快照 = saveindex + 该槽位全部世界文件

时间戳后缀的含义：
    无后缀  = 用户手动备份
    _auto   = 自动备份（存档变化时抓的）
    _pre    = 恢复前自动拍的"后悔药"
只有 _auto 归入自动备份的份数上限，手动备份不会被自动备份挤掉。
"""
import json
import os
import re
import shutil
import subprocess
import sys
import time

from klei_format import CHARACTER_CN, MODE_NAME_CN, describe_slot, load_slots

APP_NAME = "dst-saver"

# PyInstaller onefile 下 __file__ 指向临时解压目录，冻结时改用 exe 所在目录
if getattr(sys, "frozen", False):
    APP_DIR = os.path.dirname(os.path.abspath(sys.executable))
else:
    APP_DIR = os.path.dirname(os.path.abspath(__file__))
CONFIG_FILE = os.path.join(APP_DIR, "dst_saver_config.json")

# 时间戳目录名：20261027_091233 / 20261027_091233_auto / 20261027_091233_auto_2
_STAMP_RE = re.compile(r"^(\d{8}_\d{6})(?:_([a-z]+))?(?:_(\d+))?$")

# 一份备份里的 saveindex 不会再变，解析一次就缓存住，翻历史不重复解码
_meta_cache = {}


# ---------------- 配置 ----------------

def load_config():
    try:
        with open(CONFIG_FILE, encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def save_config(cfg):
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


def default_backup_root(save_dir=None):
    """默认备份目录：软件自管，放在 exe/脚本同级，不污染用户的文档目录。"""
    return os.path.join(APP_DIR, "backups")


# ---------------- 找存档 ----------------

def _steam_paths_from_registry():
    paths = []
    try:
        import winreg
        for hive, key in (
            (winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam"),
            (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam"),
        ):
            try:
                with winreg.OpenKey(hive, key) as k:
                    value, _ = winreg.QueryValueEx(k, "SteamPath")
                    paths.append(value)
            except OSError:
                pass
    except Exception:
        pass
    return paths


def _steam_libraries(steam_root):
    """Steam 可能把游戏装在别的盘，库列表在 libraryfolders.vdf 里。"""
    libs = [steam_root]
    vdf = os.path.join(steam_root, "steamapps", "libraryfolders.vdf")
    try:
        text = open(vdf, encoding="utf-8", errors="replace").read()
        libs += re.findall(r'"path"\s+"([^"]+)"', text)
    except OSError:
        pass
    return [lib.replace("\\\\", "\\") for lib in libs]


def locate_save_dirs():
    """自动扫描所有可能的饥荒单机存档目录，返回去重后的列表。"""
    found = []
    docs = os.path.join(os.path.expanduser("~"), "Documents")

    # 1) Steam 版：<steam>/userdata/<steamid>/219740/remote
    steam_roots = _steam_paths_from_registry()
    if not steam_roots:
        for path in (r"C:\Program Files (x86)\Steam", r"D:\Steam", r"E:\Steam"):
            if os.path.isdir(path):
                steam_roots.append(path)
    for root in steam_roots:
        for lib in _steam_libraries(root):
            userdata = os.path.join(lib, "userdata")
            if not os.path.isdir(userdata):
                continue
            for uid in os.listdir(userdata):
                candidate = os.path.join(userdata, uid, "219740", "remote")
                if os.path.isfile(os.path.join(candidate, "saveindex")):
                    found.append(candidate)

    # 2) 独立版 / 部分 Steam 版：文档目录
    for candidate in (os.path.join(docs, "Klei", "DoNotStarve", "save"),
                      os.path.join(docs, "Klei", "DoNotStarve")):
        if os.path.isfile(os.path.join(candidate, "saveindex")):
            found.append(candidate)

    # 去重（Windows 路径大小写不敏感）
    result = []
    seen = set()
    for path in found:
        norm = os.path.normpath(path)
        if norm.lower() not in seen:
            seen.add(norm.lower())
            result.append(norm)
    return result


# ---------------- 世界 ----------------

def list_worlds(save_dir):
    """返回非空槽位。每个槽位额外带一个 display 字段（中文描述）。"""
    slots = load_slots(save_dir) or []
    worlds = []
    for slot in slots:
        if not slot["files"]:
            continue  # 空槽位没有文件，不值得显示
        slot["display"] = describe_slot(slot)
        worlds.append(slot)
    return worlds


def world_meta(slot):
    """把槽位里的英文标识翻成界面上要显示的中文片段。"""
    return {
        "character": CHARACTER_CN.get(slot["character"], slot["character"]),
        "mode": MODE_NAME_CN.get(slot["mode"], slot["mode"] or "未知"),
        "day": slot["day"],
    }


# ---------------- 备份 ----------------

def _slot_dir(backup_root, slot_id):
    return os.path.join(backup_root, f"slot_{slot_id}")


def backup_slot(save_dir, slot, backup_root, tag=""):
    """给一个槽位拍快照：saveindex + 该槽位所有世界文件（含洞穴/火山）。

    tag="auto" 表示自动备份，tag="pre" 表示恢复前的安全快照。
    返回快照目录路径。
    """
    stamp = time.strftime("%Y%m%d_%H%M%S")
    name = f"{stamp}_{tag}" if tag else stamp
    base = _slot_dir(backup_root, str(slot["index"]))
    dest = os.path.join(base, name)

    # 同一秒内连续备份（自动备份 + 手动点一下）会撞名，加序号
    index = 1
    while os.path.isdir(dest):
        index += 1
        dest = os.path.join(base, f"{name}_{index}")

    os.makedirs(dest, exist_ok=True)
    copied = 0
    # saveindex 必须一起备份，否则恢复后游戏索引和文件对不上
    for fname in sorted(set(slot["files"]) | {"saveindex"}):
        src = os.path.join(save_dir, fname)
        if os.path.isfile(src):
            shutil.copy2(src, os.path.join(dest, fname))
            copied += 1
    if not copied:
        shutil.rmtree(dest, ignore_errors=True)
        raise RuntimeError("没有复制到任何文件，备份已取消")
    return dest


def _read_meta(backup_path, slot_id):
    """解析备份里的 saveindex，拿到"当时"的角色/模式/天数。

    这样备份历史能显示 274 天 vs 273 天，而不是一串时间戳让人猜。
    备份内容不会变，所以结果按路径缓存。
    """
    key = (backup_path, str(slot_id))
    if key in _meta_cache:
        return _meta_cache[key]

    meta = {}
    try:
        for slot in load_slots(backup_path) or []:
            if str(slot["index"]) == str(slot_id):
                meta = world_meta(slot)
                break
    except Exception:
        meta = {}
    _meta_cache[key] = meta
    return meta


def _dir_size(path):
    total = 0
    try:
        for name in os.listdir(path):
            full = os.path.join(path, name)
            if os.path.isfile(full):
                total += os.path.getsize(full)
    except OSError:
        pass
    return total


def list_backups(backup_root, slot_id):
    """返回该槽位所有备份，最新的在前。

    每项：{path, stamp, tag, time, files, total_mb, character, mode, day}
    """
    folder = _slot_dir(backup_root, str(slot_id))
    if not os.path.isdir(folder):
        return []

    items = []
    for name in os.listdir(folder):
        path = os.path.join(folder, name)
        if not os.path.isdir(path):
            continue
        match = _STAMP_RE.match(name)
        if match:
            stamp, tag = match.group(1), (match.group(2) or "")
            try:
                display_time = time.strftime("%m-%d %H:%M", time.strptime(stamp, "%Y%m%d_%H%M%S"))
                full_time = time.strftime("%Y-%m-%d %H:%M:%S", time.strptime(stamp, "%Y%m%d_%H%M%S"))
            except ValueError:
                display_time = full_time = name
        else:
            # 不认识的目录名：原样显示，不要因为解析失败就把它藏起来
            stamp, tag, display_time, full_time = name, "", name, name

        size = _dir_size(path)
        meta = _read_meta(path, slot_id)
        items.append({
            "path": path,
            "stamp": stamp,
            "tag": tag,
            "time": display_time,
            "full_time": full_time,
            "files": os.listdir(path),
            "total_mb": round(size / 1048576, 2),
            "size_bytes": size,
            "character": meta.get("character", ""),
            "mode": meta.get("mode", ""),
            "day": meta.get("day"),
        })

    items.sort(key=lambda b: b["stamp"], reverse=True)
    return items


def enforce_keep(backup_root, slot_id, keep_manual=10, keep_auto=5):
    """按份数清理旧备份，返回删掉的份数。

    手动备份和自动备份分开计数：否则玩一晚上几十份自动备份
    会把你精心留着的"打 BOSS 前"给冲掉。
    _pre（恢复前快照）归入手动组，因为它同样是用户动作产生的。
    """
    backups = list_backups(backup_root, slot_id)
    manual = [b for b in backups if b["tag"] != "auto"]
    automatic = [b for b in backups if b["tag"] == "auto"]

    removed = 0
    for group, limit in ((manual, keep_manual), (automatic, keep_auto)):
        if limit <= 0:
            continue
        for item in group[limit:]:
            shutil.rmtree(item["path"], ignore_errors=True)
            _meta_cache.pop((item["path"], str(slot_id)), None)
            removed += 1
    return removed


def delete_backup(path, slot_id=None):
    """删掉一份备份。slot_id 只是为了顺手清掉缓存。"""
    shutil.rmtree(path)
    if slot_id is not None:
        for key in [k for k in _meta_cache if k[0] == path]:
            _meta_cache.pop(key, None)


def restore_slot(save_dir, backup_path):
    """把备份覆盖回存档目录。调用方必须先确认游戏已退出。"""
    if not os.path.isdir(backup_path):
        raise RuntimeError("备份目录不存在")

    restored = []
    for fname in os.listdir(backup_path):
        src = os.path.join(backup_path, fname)
        if os.path.isfile(src):
            shutil.copy2(src, os.path.join(save_dir, fname))
            restored.append(fname)

    if "saveindex" not in restored:
        raise RuntimeError("备份中缺少 saveindex，拒绝恢复")
    return restored


# ---------------- 统计 ----------------

def stats(backup_root):
    """整体占用统计：总量 + 每个槽位 + 份数。给世界栏底部和设置页用。"""
    total = 0
    per_slot = {}
    count = 0
    if not os.path.isdir(backup_root):
        return {"total_bytes": 0, "count": 0, "per_slot": {}}

    for name in os.listdir(backup_root):
        path = os.path.join(backup_root, name)
        if not os.path.isdir(path) or not name.startswith("slot_"):
            continue
        slot_id = name[len("slot_"):]
        size = 0
        n = 0
        for entry in os.listdir(path):
            sub = os.path.join(path, entry)
            if os.path.isdir(sub):
                size += _dir_size(sub)
                n += 1
        per_slot[slot_id] = {"bytes": size, "count": n}
        total += size
        count += n
    return {"total_bytes": total, "count": count, "per_slot": per_slot}


def fmt_size(num_bytes):
    """人类可读的体积。"""
    if num_bytes < 1024:
        return f"{num_bytes} B"
    if num_bytes < 1048576:
        return f"{num_bytes / 1024:.0f} KB"
    if num_bytes < 1073741824:
        return f"{num_bytes / 1048576:.1f} MB"
    return f"{num_bytes / 1073741824:.2f} GB"


def is_game_running():
    """恢复前必须确认游戏没在跑，否则存档会被游戏回写覆盖。"""
    try:
        result = subprocess.run(
            ["tasklist", "/FI", "IMAGENAME eq dontstarve.exe", "/NH"],
            capture_output=True, text=True, timeout=10, encoding="gbk", errors="replace",
        )
        return "dontstarve.exe" in (result.stdout or "").lower()
    except Exception:
        return False


if __name__ == "__main__":
    dirs = locate_save_dirs()
    print("检测到存档目录:", dirs)
    if dirs:
        save_dir = dirs[0]
        root = default_backup_root(save_dir)
        print("世界列表:")
        for world in list_worlds(save_dir):
            print("  ", world["display"], "->", world["files"])
        print("默认备份目录:", root)
        print("统计:", stats(root))
        print("游戏运行中:" if is_game_running() else "游戏未运行")
