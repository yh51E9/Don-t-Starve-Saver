# -*- coding: utf-8 -*-
"""Klei 饥荒单机版存档格式解析。

saveindex 文件结构（实测）:
  "KLEI     1D"  (11 字节头)
  + base64 文本
  + 解码后偏移若干字节处为 zlib 流
  + zlib 解压后为 Lua 表文本: return { slots = { ... } }
"""
import base64
import os
import re
import zlib


def decode_klei_file(path: str) -> str:
    """解码 KLEI 格式存档文件, 返回 Lua 表文本。失败抛 ValueError。"""
    raw = open(path, "rb").read()
    # 兼容 "KLEI     1D" / "KLEI     1" 等头长度, 从第 10/11 字节开始试
    for start in (10, 11, 12):
        body = re.sub(rb"[^A-Za-z0-9+/=]", b"", raw[start:])
        for cut in range(0, 3):
            for pad in range(0, 4):
                try:
                    dec = base64.b64decode(body[cut:] + b"=" * pad)
                except Exception:
                    continue
                for off in range(0, 40):
                    try:
                        return zlib.decompress(dec[off:]).decode("utf-8")
                    except Exception:
                        continue
    raise ValueError(f"无法解码存档文件: {path}")


def parse_lua_table(text: str):
    """极简 Lua 表解析器, 支持字符串/数字/布尔/嵌套表/数组。"""
    pos = 0
    n = len(text)

    def skip_ws():
        nonlocal pos
        while pos < n and text[pos] in " \t\r\n":
            pos += 1

    def parse_value():
        nonlocal pos
        skip_ws()
        c = text[pos]
        if c == "{":
            return parse_table()
        if c == '"':
            return parse_string()
        m = re.match(r"[-0-9.eE+]+", text[pos:])
        if m:
            num = m.group(0)
            pos += len(num)
            return float(num) if ("." in num or "e" in num.lower()) else int(num)
        m = re.match(r"\w+", text[pos:])
        if m:
            word = m.group(0)
            pos += len(word)
            if word == "true":
                return True
            if word == "false":
                return False
            if word in ("return", "nil"):
                return parse_value()
            return word
        raise ValueError(f"解析失败 @ {pos}: {text[pos:pos+30]!r}")

    def parse_string():
        nonlocal pos
        out = []
        pos += 1  # 跳过 "
        while pos < n:
            c = text[pos]
            if c == "\\":
                nxt = text[pos + 1]
                esc = {"n": "\n", "t": "\t", '"': '"', "\\": "\\"}
                out.append(esc.get(nxt, nxt))
                pos += 2
                continue
            if c == '"':
                pos += 1
                return "".join(out)
            out.append(c)
            pos += 1
        raise ValueError("字符串未闭合")

    def parse_table():
        nonlocal pos
        result = {}
        array_mode_items = []
        pos += 1  # {
        while True:
            skip_ws()
            if text[pos] == "}":
                pos += 1
                break
            # 尝试 key = value (支持 "key"= 与 ["key"]= 与 key=)
            is_pair = False
            key = None
            if text[pos] == "[" and pos + 1 < n and text[pos + 1] == '"':
                pos += 2  # 跳过 ["
                key = parse_string()
                skip_ws()
                if pos < n and text[pos] == "]":
                    pos += 1
                    skip_ws()
                    if pos < n and text[pos] == "=":
                        pos += 1
                        value = parse_value()
                        is_pair = True
            elif text[pos] == '"':
                save = pos
                key = parse_string()
                skip_ws()
                if pos < n and text[pos] == "=":
                    pos += 1
                    value = parse_value()
                    is_pair = True
                else:
                    pos = save
            else:
                m = re.match(r"[\w.]+", text[pos:])
                if m:
                    save = pos
                    key = m.group(0)
                    pos += len(key)
                    skip_ws()
                    if pos < n and text[pos] == "=":
                        pos += 1
                        value = parse_value()
                        is_pair = True
                    else:
                        pos = save
            if is_pair:
                result[key] = value
            else:
                value = parse_value()
                array_mode_items.append(value)
            skip_ws()
            if pos < n and text[pos] == ",":
                pos += 1
            elif pos < n and text[pos] == ";":
                pos += 1
        if array_mode_items:
            if result:
                result["__array__"] = array_mode_items
            else:
                return array_mode_items
        return result

    return parse_value()


MODE_NAME_CN = {
    "survival": "巨人国",
    "shipwrecked": "海难",
    "porkland": "哈姆雷特",
    "adventure": "冒险模式",
    "cave": "洞穴",
    "volcano": "火山",
    "screecher": "惊魂夜",
}


def load_slots(save_dir: str):
    """读取 saveindex, 返回槽位列表。

    每个槽位: {
      index, character, mode, day, files(去重后的世界文件名列表), raw
    }
    """
    idx_path = os.path.join(save_dir, "saveindex")
    if not os.path.isfile(idx_path):
        return None
    data = parse_lua_table(decode_klei_file(idx_path))
    slots_raw = data.get("slots") if isinstance(data, dict) else None
    items = []  # (槽位标识, dict)
    if isinstance(slots_raw, list):
        items = [(str(i + 1), s) for i, s in enumerate(slots_raw) if isinstance(s, dict)]
    elif isinstance(slots_raw, dict):
        for i, s in enumerate(slots_raw.get("__array__", []) or []):
            if isinstance(s, dict):
                items.append((str(i + 1), s))
        for name, s in slots_raw.items():
            if name != "__array__" and isinstance(s, dict):
                items.append((name, s))
    slots = []
    for sid, s in items:
        mode = s.get("current_mode", "")
        files = []
        day = 0
        modes = s.get("modes", {})
        if isinstance(modes, dict):
            for mname, mval in modes.items():
                if not isinstance(mval, dict):
                    continue
                d = mval.get("day")
                if isinstance(d, int) and d > day:
                    day = d
                fl = mval.get("files", [])
                if isinstance(fl, list):
                    files.extend(f for f in fl if isinstance(f, str))
                if isinstance(mval.get("file"), str):
                    files.append(mval["file"])
                # 洞穴层级 cave_levels
                cl = mval.get("cave_levels")
                if isinstance(cl, list):
                    files.extend(f for f in cl if isinstance(f, str))
        slots.append({
            "index": sid,
            "character": s.get("character", "?"),
            "mode": mode,
            "day": day,
            "files": sorted(set(files)),
            "raw": s,
        })
    return slots


CHARACTER_CN = {
    "wilson": "威尔逊", "willow": "薇洛", "wolfgang": "沃尔夫冈", "wendy": "温蒂",
    "wx78": "机器人WX-78", "wickerbottom": "薇克巴顿", "woodie": "伍迪", "wes": "韦斯",
    "wmaxwell": "麦斯威尔", "wathgrithr": "薇格弗德", "webber": "韦伯", "walani": "瓦拉尼",
    "warly": "沃利", "woodlegs": "木腿船长", "wilba": "薇尔芭", "wormwood": "沃姆伍德",
    "wheeler": "惠勒", "wortox": "沃拓克斯", "walter": "沃尔特", "wanda": "旺达",
    "warbucks": "沃巴克", "wonkey": "威尔逊猴", "wagstaff": "瓦格斯塔夫",
}


def describe_slot(slot: dict) -> str:
    mode = MODE_NAME_CN.get(slot["mode"], slot["mode"] or "未知")
    ch = CHARACTER_CN.get(slot["character"], slot["character"])
    return f"槽位{slot['index']} - {ch} - {mode} - {slot['day']}天"


if __name__ == "__main__":
    import sys
    d = sys.argv[1] if len(sys.argv) > 1 else r"D:\Software\Steam\userdata\1222722443\219740\remote"
    for s in load_slots(d) or []:
        print(describe_slot(s), "| files:", ",".join(s["files"]))
