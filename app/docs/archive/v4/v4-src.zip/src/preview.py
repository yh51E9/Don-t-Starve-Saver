# 预览脚本：指定主题 / 页面 / 强调色启动主程序，方便截图验证（不参与打包）
# 用法：python preview.py [auto|dark|light] [backup|settings] [ember|azure|moss|plum]
import sys

import app

theme_mode = sys.argv[1] if len(sys.argv) > 1 else "auto"
page = sys.argv[2] if len(sys.argv) > 2 else "backup"
accent = sys.argv[3] if len(sys.argv) > 3 else "ember"

app.cfg["theme_mode"] = theme_mode
app.cfg["accent"] = accent
app.state["page"] = page

import main

main.main()
