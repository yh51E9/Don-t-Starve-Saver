# -*- coding: utf-8 -*-
"""widgets.py —— 通用小控件 + 窗口外壳。

这里放两样东西：
  1. 全程序共享的 tag 常量（避免在三个文件里手写字符串拼错）
  2. 窗口外壳的 Win32 操作：无边框窗口的拖动、最小化、最大化、圆角、暗色边框

界面用到的每个"零件"（标题、提示、分隔线、行内小按钮）也在这里，
这样 pages.py 只关心"摆在哪"，不关心"长什么样"。
"""
import ctypes
import time

import dearpygui.dearpygui as dpg

import theme

user32 = ctypes.windll.user32
dwmapi = ctypes.windll.dwmapi

# ---------------- tag 常量 ----------------
# 静态骨架的 tag 在这里；动态生成的行用 "world_row_<id>" / "bk_<stamp>" 这类前缀
TAGS = {
    "root": "root",
    "titlebar": "titlebar",
    "nav_backup": "nav_backup",
    "nav_settings": "nav_settings",
    "win_min": "win_min",
    "win_max": "win_max",
    "win_close": "win_close",
    "toolbar": "toolbar",
    "combo_dir": "combo_dir",
    "auto_btn": "auto_btn",
    "body": "body",
    "rail": "rail",
    "rail_head": "rail_head",
    "rail_list": "rail_list",
    "rail_foot": "rail_foot",
    "main": "main",
    "main_body": "main_body",
    "status_text": "status_text",
}

# 标题栏上不允许拖动的区域（按钮）
_NO_DRAG = ("nav_backup", "nav_settings", "win_min", "win_max", "win_close")

TITLEBAR_H = 48
TOOLBAR_H = 56
STATUSBAR_H = 28
RAIL_W = 320
# 顶层区块之间的纵向间距。必须和主题里的 ItemSpacing 纵向值一致，
# 因为负高度是"父高 - N"，算错一点就会把最后一块挤出窗口。
GAP = 8


# ---------------- Win32 窗口外壳 ----------------

class _POINT(ctypes.Structure):
    _fields_ = [("x", ctypes.c_long), ("y", ctypes.c_long)]


class _RECT(ctypes.Structure):
    _fields_ = [("left", ctypes.c_long), ("top", ctypes.c_long),
                ("right", ctypes.c_long), ("bottom", ctypes.c_long)]


def get_hwnd():
    """按 PID 找主窗口。

    必须同时过滤"可见"和"有标题"：
    进程里还有 MSCTFIME UI 这类输入法隐藏窗口，它们也有标题，
    但属于别的线程，对它们 SetWindowTextW 会静默失败。
    """
    import os
    targets = []
    proc_type = ctypes.WINFUNCTYPE(ctypes.c_bool, ctypes.c_void_p, ctypes.c_void_p)

    def each(hwnd, _):
        pid = ctypes.c_uint()
        user32.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if (pid.value == os.getpid()
                and user32.IsWindowVisible(hwnd)
                and user32.GetWindowTextLengthW(hwnd) > 0):
            targets.append(hwnd)
        return True

    user32.EnumWindows(proc_type(each), None)
    return targets[0] if targets else None


def current_title():
    hwnd = get_hwnd()
    if not hwnd:
        return ""
    buf = ctypes.create_unicode_buffer(256)
    user32.GetWindowTextW(ctypes.c_void_p(hwnd), buf, 256)
    return buf.value


def ensure_title(text):
    """确保窗口标题是 text，返回 True 表示"本来就已经正确"。

    DPG 在头几帧渲染时会用自己的 UTF-8 标题覆盖一次（中文变乱码），
    所以要连续几帧盯着，直到它不再改。
    """
    hwnd = get_hwnd()
    if not hwnd:
        return False
    if current_title() == text:
        return True
    user32.SetWindowTextW(ctypes.c_void_p(hwnd), text)
    return False


def sync_window_chrome(dark):
    """让系统绘制的那一圈边框跟着主题走。

    无边框窗口在 Win11 上仍有一条 1px 边框，默认是浅灰，
    暗色模式下会显得像没对齐的描边。把边框色设成背景色就"消失在背景里"。
    """
    hwnd = get_hwnd()
    if not hwnd:
        return
    c = theme.colors()
    bg = c["bg"]

    def set_int(attribute, value):
        v = ctypes.c_int(value)
        return dwmapi.DwmSetWindowAttribute(ctypes.c_void_p(hwnd), ctypes.c_uint(attribute),
                                            ctypes.byref(v), ctypes.sizeof(v))

    # 20 = Win10 1809+ 的暗色模式, 19 = 更早的预览版
    for attribute in (20, 19):
        if set_int(attribute, 1 if dark else 0) == 0:
            break
    set_int(33, 2)  # 圆角：2 = 系统默认圆角
    # COLORREF 是 0x00BBGGRR，注意和 RGB 反序
    border = bg[0] | (bg[1] << 8) | (bg[2] << 16)
    set_int(34, border)
    set_int(35, border)


def work_area():
    """屏幕可用区（去掉任务栏），返回 (左, 上, 宽, 高)。"""
    r = _RECT()
    user32.SystemParametersInfoW(0x0030, 0, ctypes.byref(r), 0)  # SPI_GETWORKAREA
    return r.left, r.top, r.right - r.left, r.bottom - r.top


def minimize():
    hwnd = get_hwnd()
    if hwnd:
        user32.ShowWindow(hwnd, 6)  # SW_MINIMIZE


def restore():
    hwnd = get_hwnd()
    if hwnd:
        user32.ShowWindow(hwnd, 9)  # SW_RESTORE
        user32.SetForegroundWindow(hwnd)


_win = {"max": False, "normal": None}


def toggle_maximize():
    """最大化 = 铺满工作区。无边框窗口没有系统最大化按钮，只能自己算。"""
    if _win["max"] and _win["normal"]:
        pos, (w, h) = _win["normal"]
        dpg.set_viewport_width(w)
        dpg.set_viewport_height(h)
        dpg.set_viewport_pos(pos)
        _win["max"] = False
    else:
        _win["normal"] = (dpg.get_viewport_pos(),
                          (dpg.get_viewport_width(), dpg.get_viewport_height()))
        left, top, w, h = work_area()
        dpg.set_viewport_width(w)
        dpg.set_viewport_height(h)
        dpg.set_viewport_pos([left, top])
        _win["max"] = True


def is_maximized():
    return _win["max"]


def apply_window_chrome(title, dark, on_close):
    """窗口一被系统真正创建出来，就把标题、边框色、关闭拦截全部装上。

    不能在 show_viewport 之后立刻做：那一刻 GLFW 的窗口可能还没建好，
    get_hwnd 会返回 None，于是标题保持 DPG 写入的 UTF-8 乱码。
    所以由主循环每帧重试，装好一次就不再试。
    """
    if not get_hwnd():
        return False
    ensure_title(title)
    sync_window_chrome(dark)
    install_close_hook(on_close)
    return True


# ---------------- 关闭拦截 ----------------
# 没有标题栏了，但 Alt+F4 和任务栏右键"关闭"仍会发 WM_CLOSE。
# 这里接管它，交给调用方决定是隐藏到托盘还是退出。
_WNDPROC = ctypes.WINFUNCTYPE(ctypes.c_ssize_t, ctypes.c_void_p, ctypes.c_uint,
                              ctypes.c_size_t, ctypes.c_size_t)
_old_wndproc = None
_new_wndproc = None


def install_close_hook(on_close):
    global _old_wndproc, _new_wndproc
    hwnd = get_hwnd()
    if not hwnd:
        return False

    user32.CallWindowProcW.restype = ctypes.c_ssize_t
    user32.CallWindowProcW.argtypes = [ctypes.c_ssize_t, ctypes.c_void_p, ctypes.c_uint,
                                       ctypes.c_size_t, ctypes.c_size_t]

    def proc(h, msg, wparam, lparam):
        if msg == 0x0010:  # WM_CLOSE
            on_close()
            return 0
        return user32.CallWindowProcW(_old_wndproc, h, msg, wparam, lparam)

    _new_wndproc = _WNDPROC(proc)
    set_ptr = getattr(user32, "SetWindowLongPtrW", None)
    if set_ptr is None:
        return False
    set_ptr.restype = ctypes.c_ssize_t
    set_ptr.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_ssize_t]
    _old_wndproc = set_ptr(hwnd, -4, ctypes.cast(_new_wndproc, ctypes.c_void_p).value)
    return True


# ---------------- 拖动 ----------------
# 用屏幕坐标算增量，不能用 get_mouse_pos：那是视口内坐标，
# 窗口一动鼠标相对位置就变，会自己抖起来。
_drag = {"on": False, "cursor": (0, 0), "last_click": 0.0}


def _screen_cursor():
    p = _POINT()
    user32.GetCursorPos(ctypes.byref(p))
    return p.x, p.y


def _over_button():
    for tag in _NO_DRAG:
        if dpg.does_item_exist(TAGS.get(tag, tag)) and dpg.is_item_hovered(TAGS.get(tag, tag)):
            return True
    return False


def tick_drag():
    """每帧调用：在标题栏按下鼠标即可拖窗口，双击标题栏切换最大化。"""
    down = dpg.is_mouse_button_down(0)
    if not down:
        _drag["on"] = False
        return

    if _drag["on"]:
        if _win["max"]:
            return  # 最大化状态下不拖，省掉"拖出来还原"的复杂度
        cx, cy = _screen_cursor()
        px, py = _drag["cursor"]
        dx, dy = cx - px, cy - py
        if dx or dy:
            _drag["cursor"] = (cx, cy)
            pos = dpg.get_viewport_pos()
            dpg.set_viewport_pos([pos[0] + dx, pos[1] + dy])
        return

    mx, my = dpg.get_mouse_pos()
    if my >= TITLEBAR_H or _over_button():
        return

    now = time.time()
    if now - _drag["last_click"] < 0.35:
        toggle_maximize()
    _drag["last_click"] = now
    _drag["on"] = True
    _drag["cursor"] = _screen_cursor()


# ---------------- 视觉零件 ----------------

def icon(name, role="icon", color_key=None, tag=None):
    """图标字形（Segoe Fluent Icons）。拿不到图标字体时退回一个安全的圆点。"""
    glyph = theme.ICONS.get(name, "\u25CF") if theme.has_icons() else "\u25CF"
    kwargs = {}
    if tag:
        kwargs["tag"] = tag
    if color_key:
        kwargs["color"] = theme.colors()[color_key]
    item = dpg.add_text(glyph, **kwargs)
    dpg.bind_item_font(item, theme.font(role))
    return item


def icon_button(name, callback=None, user_data=None, width=32, height=32,
                danger=False, tag=None, role="icon"):
    """纯图标按钮。DPG 一个控件只能挂一种字体，图标和文字没法混排，
    所以只有含义明确的按钮（关闭/刷新/文件夹）才做纯图标。"""
    kwargs = {"label": theme.ICONS.get(name, ""), "callback": callback,
              "user_data": user_data, "width": width, "height": height}
    if tag:
        kwargs["tag"] = tag
    item = dpg.add_button(**kwargs)
    dpg.bind_item_font(item, theme.font(role))
    theme.paint(item, "ghost_danger" if danger else "ghost")
    return item


def text(value, role="body", color_key=None, tag=None, wrap=0):
    """带字体和颜色的文本。所有文字都走这里，字号才能跟着设置一起变。"""
    kwargs = {}
    if tag:
        kwargs["tag"] = tag
    if color_key:
        kwargs["color"] = theme.colors()[color_key]
    if wrap:
        kwargs["wrap"] = wrap
    item = dpg.add_text(value, **kwargs)
    dpg.bind_item_font(item, theme.font(role))
    return item


def hint(value, tag=None):
    """辅助说明文字：小一号、次要色。"""
    return text(value, role="meta", color_key="text3", tag=tag)


def section(value):
    """区块标题：等线 Bold，比正文大一号，不用颜色强调。"""
    return text(value, role="head", color_key="text")


def hairline(pad_top=0, pad_bottom=0):
    """一条分隔线。用留白分组优于用线条，所以只在真正需要断句的地方画。"""
    if pad_top:
        dpg.add_spacer(height=pad_top)
    dpg.add_separator()
    if pad_bottom:
        dpg.add_spacer(height=pad_bottom)


def ghost_button(label, callback=None, user_data=None, width=0, height=0, danger=False, tag=None):
    """行内操作按钮：无底、悬停才浮起。恢复/删除这类都用它，避免一堆色块。"""
    kwargs = {"label": label, "callback": callback, "user_data": user_data}
    if width:
        kwargs["width"] = width
    if height:
        kwargs["height"] = height
    if tag:
        kwargs["tag"] = tag
    item = dpg.add_button(**kwargs)
    dpg.bind_item_font(item, theme.font("meta"))
    theme.paint(item, "ghost_danger" if danger else "ghost")
    return item


def primary_button(label, callback=None, user_data=None, width=0, height=0, tag=None):
    """主动作按钮。全界面只应该出现一个。"""
    kwargs = {"label": label, "callback": callback, "user_data": user_data}
    if width:
        kwargs["width"] = width
    if height:
        kwargs["height"] = height
    if tag:
        kwargs["tag"] = tag
    item = dpg.add_button(**kwargs)
    dpg.bind_item_font(item, theme.font("body"))
    theme.paint(item, "primary")
    return item
