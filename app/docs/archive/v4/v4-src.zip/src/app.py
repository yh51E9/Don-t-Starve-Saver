# -*- coding: utf-8 -*-
"""app.py —— 全局状态、业务回调、动态区域渲染。

界面分两种东西：
  · 静态骨架（标题栏、工具条、状态栏）—— 在 pages.py 里搭一次就不动
  · 动态区域（世界栏、备份时间轴、设置页）—— 由这个文件按状态反复重画

线程规则：Dear PyGui 不是线程安全的。耗时的备份/恢复放进线程，
结果只写进 state 里的几个"信箱"字段，由主循环 on_frame 取走再更新界面。
"""
import os
import queue
import threading
import time

import dearpygui.dearpygui as dpg

import backup_core as bc
import theme
import widgets
from widgets import TAGS

# ---------------- 配置 ----------------
cfg = bc.load_config()


def cfg_get(key, default=None):
    value = cfg.get(key, default)
    return default if value is None or value == "" else value


# 旧版本把备份放在我的文档里，启动时静默迁移到软件自管目录
_OLD_ROOT = os.path.join(os.path.expanduser("~"), "Documents", "Klei", "DST-Saver-Backups")
if cfg.get("backup_root") == _OLD_ROOT:
    cfg["backup_root"] = bc.default_backup_root()
    bc.save_config(cfg)

THEME_OPTIONS = {"auto": "跟随系统", "dark": "暗色", "light": "亮色"}
CLOSE_OPTIONS = {"ask": "每次询问", "tray": "最小化到托盘", "exit": "直接退出"}
REVERSE = {v: k for k, v in {**THEME_OPTIONS, **CLOSE_OPTIONS}.items()}

AUTO_COOLDOWN = 60      # 同一个世界两次自动备份的最小间隔（秒）
WATCH_INTERVAL = 5      # 巡检存档文件的间隔（秒）

state = {
    "page": "backup",
    "save_dir": None,
    "worlds": [],
    "selected": None,     # 当前选中的世界（槽位 dict）
    "backups": [],
    "busy": False,        # 正在备份/恢复，防止并发
    "status": None,       # (文本, 是否错误, 过期时间戳)
    "auto_on": bool(cfg_get("auto_backup", True)),
    "queue": queue.Queue(),
    "pending": {},        # 后台线程写给主线程的信箱
    "quit": False,
    "modal_open": False,
    "frame": 0,
    "dirty": False,
    "last_auto": {},
}

# pages.py 在构建完成后把自己的重建函数注册进来，避免循环 import
# pages.py 在构建时把自己的渲染函数注册进来（见 bind_render），
# 这样 app 知道"该画什么"，但不需要 import pages，避免循环依赖
RENDER = {"all": lambda: None, "settings": lambda container: None}


def bind_render(all_views, settings_view=None):
    RENDER["all"] = all_views
    if settings_view:
        RENDER["settings"] = settings_view


# ---------------- 小工具 ----------------

def backup_root():
    return cfg_get("backup_root", bc.default_backup_root())


def keep_manual():
    return int(cfg_get("keep", 10))


def keep_auto():
    return int(cfg_get("keep_auto", 5))


def set_status(message, error=False, seconds=3.0):
    state["status"] = (message, error, time.time() + seconds)
    if dpg.does_item_exist(TAGS["status_text"]):
        dpg.configure_item(TAGS["status_text"], default_value=message)


def open_path(path):
    if path and os.path.isdir(path):
        os.startfile(path)


def slot_id_of(world):
    return str(world["index"]) if world else None


# ---------------- 读取数据 ----------------

def load_worlds(save_dir=None):
    """读存档目录，刷新世界列表。会尽量保留当前选中的世界。"""
    save_dir = save_dir or (dpg.get_value(TAGS["combo_dir"]) if dpg.does_item_exist(TAGS["combo_dir"]) else None)
    if not save_dir or not os.path.isfile(os.path.join(save_dir, "saveindex")):
        set_status("存档目录无效：找不到 saveindex", error=True)
        return

    state["save_dir"] = save_dir
    cfg["save_dir"] = save_dir

    previous = slot_id_of(state["selected"])
    worlds = bc.list_worlds(save_dir)
    state["worlds"] = worlds

    # 重读后优先回到原来的世界，找不到就选第一个（空着更难看）
    match = next((w for w in worlds if str(w["index"]) == previous), None)
    state["selected"] = match or (worlds[0] if worlds else None)

    if state["selected"]:
        state["backups"] = bc.list_backups(backup_root(), slot_id_of(state["selected"]))
    else:
        state["backups"] = []

    refresh_view()
    set_status(f"已加载 {len(worlds)} 个世界")


def refresh_view():
    """标记"界面该重画了"。

    不直接重画：这个函数常常是在某个按钮的回调里被调用的，
    当场把按钮自己删掉会让 DPG 炸掉。交给 on_frame 在帧边界统一处理。
    """
    state["dirty"] = True


# ---------------- 渲染：世界栏 ----------------

def render_rail():
    """世界栏。用 selectable 而不是 button：button 会把文字居中，
    导航列表看起来就像一堆被拉开的标签；selectable 天然左对齐、整行可点。
    """
    container = TAGS["rail_list"]
    if not dpg.does_item_exist(container):
        return
    dpg.delete_item(container, children_only=True)

    if not state["worlds"]:
        with dpg.group(parent=container):
            widgets.hint("没有找到世界")
            widgets.hint("检查存档目录是否正确")
        return

    selected_id = slot_id_of(state["selected"])
    # selectable 不支持 width=-1（会缩成文字宽度，整行就看不见了），
    # 所以要显式给宽度：栏宽 - 左右内边距 - 滚动条
    row_width = widgets.RAIL_W - 16 * 2 - 12
    with dpg.group(parent=container):
        for world in state["worlds"]:
            meta = bc.world_meta(world)
            sid = slot_id_of(world)
            backups = bc.list_backups(backup_root(), sid)
            # 前面那个点表示"这个世界有备份"，比在窄栏里塞份数更好读
            mark = "● " if backups else "   "
            item = dpg.add_selectable(
                label=f"{mark}{meta['character']} · {meta['mode']} · {meta['day']}天",
                width=row_width, height=32, user_data=world,
                default_value=(sid == selected_id),
                callback=on_world_clicked, tag=f"world_row_{sid}",
            )
            dpg.bind_item_font(item, theme.font("body"))
            theme.paint(item, "row_on" if sid == selected_id else "row_off")


def render_rail_footer():
    tag = TAGS["rail_foot"]
    if not dpg.does_item_exist(tag):
        return
    dpg.delete_item(tag, children_only=True)
    info = bc.stats(backup_root())
    with dpg.group(parent=tag):
        widgets.hairline(pad_top=6, pad_bottom=8)
        widgets.hint(f"{info['count']} 份备份 · 共 {bc.fmt_size(info['total_bytes'])}")


# ---------------- 渲染：主区域 ----------------

def render_detail():
    container = TAGS["main_body"]
    if not dpg.does_item_exist(container):
        return
    dpg.delete_item(container, children_only=True)

    if state["page"] == "settings":
        # 设置页的版面归 pages.py 管，通过注册表调用，避免两个文件互相 import
        RENDER["settings"](container)
        return

    world = state["selected"]
    if not world:
        _render_empty(container, "还没有选中世界",
                      "先在左侧挑一个世界，或者点「浏览」换一个存档目录")
        return

    meta = bc.world_meta(world)
    backups = state["backups"]
    total = sum(b["size_bytes"] for b in backups)
    recent = backups[0]["time"] if backups else "还没有备份"

    with dpg.group(parent=container):
        # 顶部：世界身份 + 唯一主动作
        with dpg.table(header_row=False, width=-1,
                       policy=dpg.mvTable_SizingStretchProp,
                       borders_innerH=False, borders_outerH=False,
                       borders_innerV=False, borders_outerV=False, pad_outerX=False):
            dpg.add_table_column(init_width_or_weight=1.0, width_stretch=True)
            dpg.add_table_column(width_fixed=True, init_width_or_weight=124)
            with dpg.table_row():
                with dpg.group():
                    widgets.text(f"{meta['character']} · {meta['mode']}", role="display")
                    widgets.hint(f"{meta['day']} 天 · {len(backups)} 份备份 · "
                                 f"{bc.fmt_size(total)} · 最近 {recent}")
                with dpg.group():
                    btn = widgets.primary_button("备份此世界", on_backup, width=116, height=34,
                                                 tag="btn_backup")
                    if state["busy"]:
                        dpg.configure_item(btn, enabled=False)

        dpg.add_spacer(height=14)

        if not backups:
            _render_empty(container, "这个世界还没有备份",
                          "点右上角「备份此世界」拍下第一份，之后随时能回到这一刻")
            return

        _render_timeline(container, backups)


def _render_empty(container, title, hint_text):
    """空状态：说清楚"下一步该干什么"，不是卖萌。"""
    with dpg.group(parent=container):
        dpg.add_spacer(height=18)
        widgets.text(title, role="head", color_key="text2")
        dpg.add_spacer(height=6)
        widgets.hint(hint_text)


def _render_timeline(container, backups):
    """备份时间轴。最新的一份在最上面，节点实心；其余为空心。"""
    with dpg.table(parent=container, header_row=False, width=-1,
                   policy=dpg.mvTable_SizingStretchProp,
                   borders_innerH=False, borders_outerH=False,
                   borders_innerV=False, borders_outerV=False,
                   pad_outerX=False, row_background=False):
        # 列序：节点 / 时间 / 天数 / 来源 —— 留白 —— 体积 / 操作
        # 左边回答"什么时候、多少天、怎么来的"，右边是数字和动作，中间留白分组
        dpg.add_table_column(width_fixed=True, init_width_or_weight=24)
        dpg.add_table_column(width_fixed=True, init_width_or_weight=100)
        dpg.add_table_column(width_fixed=True, init_width_or_weight=64)
        dpg.add_table_column(width_fixed=True, init_width_or_weight=72)
        dpg.add_table_column(init_width_or_weight=1.0, width_stretch=True)
        dpg.add_table_column(width_fixed=True, init_width_or_weight=80)
        dpg.add_table_column(width_fixed=True, init_width_or_weight=112)

        c = theme.colors()
        for index, backup in enumerate(backups):
            newest = index == 0
            with dpg.table_row():
                # 节点：最新的实心橙色，其余暗色空心
                widgets.text("●" if newest else "○", role="meta",
                             color_key="accent" if newest else "text3")
                widgets.text(backup["time"], role="meta",
                             color_key="text" if newest else "text2")
                widgets.text(f'{backup["day"]} 天' if backup["day"] else "—",
                             role="meta", color_key="text" if newest else "text2")
                widgets.text(_tag_label(backup["tag"]), role="meta", color_key="text3")
                dpg.add_spacer(width=1)
                widgets.text(bc.fmt_size(backup["size_bytes"]), role="meta",
                             color_key="text2")

                with dpg.group():
                    with dpg.group(horizontal=True):
                        widgets.ghost_button("恢复", on_restore, user_data=backup, width=52)
                        widgets.ghost_button("删除", on_delete, user_data=backup, width=52,
                                             danger=True)


def _tag_label(tag):
    return {"auto": "自动", "pre": "恢复前"}.get(tag, "手动")


# ---------------- 回调：世界与备份 ----------------

def on_world_clicked(sender, app_data, user_data):
    state["selected"] = user_data
    state["backups"] = bc.list_backups(backup_root(), slot_id_of(user_data))
    refresh_view()


def on_backup():
    if not state["selected"]:
        set_status("先选一个世界", error=True)
        return
    _start_backup(state["selected"], tag="", label="备份")


def on_cleanup():
    if state["busy"]:
        return
    removed = 0
    for world in state["worlds"]:
        removed += bc.enforce_keep(backup_root(), slot_id_of(world), keep_manual(), keep_auto())
    if state["selected"]:
        state["backups"] = bc.list_backups(backup_root(), slot_id_of(state["selected"]))
    refresh_view()
    set_status(f"已清理 {removed} 份旧备份" if removed else "没有需要清理的备份")


def on_restore(sender, app_data, user_data):
    backup = user_data
    if bc.is_game_running():
        set_status("检测到饥荒正在运行，请先退出游戏再恢复", error=True)
        return
    state["pending_restore"] = backup
    _show_modal("modal_restore")


def _do_restore(backup):
    state["busy"] = True
    threading.Thread(target=_restore_worker, args=(backup,), daemon=True).start()


def _restore_worker(backup):
    try:
        world = state["selected"]
        # 覆盖前先给"当前状态"拍一份后悔药，万一恢复错了还能回去
        if world:
            bc.backup_slot(state["save_dir"], world, backup_root(), tag="pre")
            bc.enforce_keep(backup_root(), slot_id_of(world), keep_manual(), keep_auto())
        files = bc.restore_slot(state["save_dir"], backup["path"])
        state["pending"] = {"msg": (f"已恢复到 {backup['time']}（{len(files)} 个文件）", False),
                            "refresh": True}
    except Exception as e:
        state["pending"] = {"msg": (f"恢复失败：{e}", True), "refresh": False}
    finally:
        state["busy"] = False


def on_delete(sender, app_data, user_data):
    state["pending_delete"] = user_data
    _show_modal("modal_delete")


def _do_delete(backup):
    try:
        bc.delete_backup(backup["path"])
        if state["selected"]:
            state["backups"] = bc.list_backups(backup_root(), slot_id_of(state["selected"]))
        refresh_view()
        set_status(f"已删除 {backup['time']} 的备份")
    except Exception as e:
        set_status(f"删除失败：{e}", error=True)


def _start_backup(world, tag="", label="备份"):
    """统一的备份入口：手动、自动、恢复前快照都走这里。"""
    if state["busy"]:
        return
    state["busy"] = True
    if dpg.does_item_exist("btn_backup"):
        dpg.configure_item("btn_backup", enabled=False)
    threading.Thread(
        target=_backup_worker,
        args=(state["save_dir"], world, backup_root(), keep_manual(), keep_auto(), tag),
        daemon=True,
    ).start()


def _backup_worker(save_dir, world, root, keep, keep_auto, tag):
    try:
        bc.backup_slot(save_dir, world, root, tag=tag)
        bc.enforce_keep(root, slot_id_of(world), keep, keep_auto)
        meta = bc.world_meta(world)
        prefix = {"auto": "自动备份", "pre": "恢复前快照"}.get(tag, "备份完成")
        state["pending"] = {"msg": (f"{prefix} · {meta['character']} {meta['day']}天", False),
                            "refresh": True}
    except Exception as e:
        state["pending"] = {"msg": (f"备份失败：{e}", True), "refresh": False}
    finally:
        state["busy"] = False


# ---------------- 回调：设置 ----------------

def on_save_settings():
    cfg["theme_mode"] = REVERSE.get(dpg.get_value("set_theme"), "auto")
    cfg["font_size"] = theme.FONT_SIZE_CHOICES[
        [theme.FONT_SIZE_LABELS[s] for s in theme.FONT_SIZE_CHOICES].index(dpg.get_value("set_font"))
    ] if dpg.does_item_exist("set_font") else theme.font_size()
    cfg["backup_root"] = dpg.get_value("set_root")
    cfg["keep"] = int(dpg.get_value("set_keep") or 10)
    cfg["keep_auto"] = int(dpg.get_value("set_keep_auto") or 5)
    cfg["close_action"] = REVERSE.get(dpg.get_value("set_close"), "ask")
    # 强调色换了一套就得重建主题对象（旧的那批颜色已经写死了）
    chosen = dpg.get_value("set_accent") if dpg.does_item_exist("set_accent") else None
    for key, spec in theme.ACCENTS.items():
        if spec["label"] == chosen:
            cfg["accent"] = key
            break
    state["auto_on"] = bool(dpg.get_value("set_auto"))
    cfg["auto_backup"] = state["auto_on"]
    bc.save_config(cfg)

    theme.set_font_size(cfg["font_size"])
    if cfg_get("accent", theme.DEFAULT_ACCENT) != theme.accent_key():
        theme.build_themes(cfg_get("accent", theme.DEFAULT_ACCENT))
    theme.apply(theme.resolve(cfg_get("theme_mode", "auto")))
    # 字号/主题都影响字体与配色，整界面重画最省事也最不会漏
    state["backups"] = bc.list_backups(backup_root(), slot_id_of(state["selected"])) if state["selected"] else []
    refresh_view()
    set_status("设置已保存")


def switch_page(page):
    state["page"] = page
    if dpg.does_item_exist(TAGS["toolbar"]):
        dpg.configure_item(TAGS["toolbar"], show=(page == "backup"))
    for tag, name in ((TAGS["nav_backup"], "backup"), (TAGS["nav_settings"], "settings")):
        if dpg.does_item_exist(tag):
            theme.paint(tag, "nav_on" if page == name else "nav_off")
    refresh_view()


def on_pick_dir(sender, app_data):
    selection = (app_data or {}).get("file_path_name") or ""
    if selection and os.path.isdir(selection):
        if dpg.does_item_exist(TAGS["combo_dir"]):
            dpg.set_value(TAGS["combo_dir"], selection)
        load_worlds(selection)


def on_pick_root(sender, app_data):
    selection = (app_data or {}).get("file_path_name") or ""
    if selection and dpg.does_item_exist("set_root"):
        dpg.set_value("set_root", selection)


# ---------------- 弹窗 ----------------

def _show_modal(tag):
    if state["modal_open"] or not dpg.does_item_exist(tag):
        return
    state["modal_open"] = True
    dpg.show_item(tag)
    # show_item 会把窗口位置重置，要在随后的几帧里持续纠正
    width, height = dpg.get_item_width(tag), dpg.get_item_height(tag)
    pos = [max(0, (dpg.get_viewport_width() - width) // 2),
           max(0, (dpg.get_viewport_height() - height) // 2)]
    dpg.set_item_pos(tag, pos)
    state["modal_nudge"] = [tag, pos, 6]


def close_modal(tag):
    if dpg.does_item_exist(tag):
        dpg.configure_item(tag, show=False)
    state["modal_open"] = False


def confirm_restore():
    backup = state.get("pending_restore")
    close_modal("modal_restore")
    if backup:
        _do_restore(backup)


def confirm_delete():
    backup = state.get("pending_delete")
    close_modal("modal_delete")
    if backup:
        _do_delete(backup)


# ---------------- 窗口关闭 ----------------

def on_close_request():
    """关闭按钮 / Alt+F4 都走这里，按配置决定：询问、隐藏到托盘、还是退出。"""
    action = cfg_get("close_action", "tray")
    if action == "tray":
        widgets.minimize()
    elif action == "exit":
        state["quit"] = True
    else:
        _show_modal("modal_close")


def confirm_close(action, remember_checkbox):
    if dpg.get_value(remember_checkbox):
        cfg["close_action"] = action
        bc.save_config(cfg)
    close_modal("modal_close")
    if action == "tray":
        widgets.minimize()
    else:
        state["quit"] = True


# ---------------- 自动备份巡检 ----------------

def start_watcher():
    threading.Thread(target=_watch_loop, daemon=True).start()


def _watch_loop():
    """盯着每个世界文件的改动，稳住了就自动备份。

    saveindex 是所有世界共用的，改它分不出是哪个世界动了，
    所以看的是具体世界文件（survival_1 / cave_1_1_1 …）。
    """
    seen, candidate, primed = {}, {}, False
    while not state["quit"]:
        time.sleep(WATCH_INTERVAL)
        if not state["auto_on"] or not state["save_dir"] or state["busy"]:
            continue

        current = {}
        for world in list(state["worlds"]):
            for fname in world["files"]:
                path = os.path.join(state["save_dir"], fname)
                try:
                    stat = os.stat(path)
                except OSError:
                    continue
                current[fname] = (stat.st_mtime, stat.st_size, world)

        if not primed:
            # 第一轮只记录现状，否则启动瞬间会给所有世界各打一份备份
            seen = {k: v[:2] for k, v in current.items()}
            primed = True
            continue

        for fname, (mtime, size, world) in current.items():
            sig = (mtime, size)
            if seen.get(fname) == sig:
                continue
            if candidate.get(fname) != sig:
                candidate[fname] = sig          # 第一次看到新值：可能还在写，再等一轮
                continue
            # 连续两轮都是同一个值 → 文件写完了
            seen[fname] = sig
            candidate.pop(fname, None)

            sid = slot_id_of(world)
            now = time.time()
            if now - state["last_auto"].get(sid, 0) < AUTO_COOLDOWN:
                continue
            state["last_auto"][sid] = now
            state["queue"].put(world)


def pump_auto_queue():
    """把巡检线程发现的变化，在主线程里变成真正的备份动作。"""
    try:
        world = state["queue"].get_nowait()
    except queue.Empty:
        return
    if state["busy"]:
        return
    _start_backup(world, tag="auto", label="自动备份")


# ---------------- 帧回调 ----------------

def on_frame():
    state["frame"] += 1
    widgets.tick_drag()

    # 界面重画放在帧边界，避免在控件自己的回调里把它删掉
    if state.pop("dirty", False):
        RENDER["all"]()

    # 后台线程写进来的结果，在这里落到界面上
    pending = state.get("pending")
    if pending:
        state["pending"] = {}
        message, is_error = pending["msg"]
        set_status(message, error=is_error, seconds=4.0)
        if pending.get("refresh"):
            if state["selected"]:
                state["backups"] = bc.list_backups(backup_root(), slot_id_of(state["selected"]))
            refresh_view()
        if dpg.does_item_exist("btn_backup"):
            dpg.configure_item("btn_backup", enabled=not state["busy"])

    pump_auto_queue()

    # 弹窗位置校正
    nudge = state.get("modal_nudge")
    if nudge:
        tag, pos, left = nudge
        if dpg.does_item_exist(tag) and dpg.is_item_shown(tag):
            dpg.set_item_pos(tag, pos)
        state["modal_nudge"] = [tag, pos, left - 1] if left > 1 else None

    # 状态提示淡出
    status = state["status"]
    if status and dpg.does_item_exist(TAGS["status_text"]):
        message, is_error, expire = status
        if time.time() > expire:
            # 消息过期后回到"就绪"，留一个空格子比留一片空白好
            dpg.configure_item(TAGS["status_text"], default_value="就绪",
                               color=theme.colors()["text3"])
            state["status"] = None
        else:
            color = theme.colors()["danger"] if is_error else theme.colors()["text2"]
            dpg.configure_item(TAGS["status_text"], color=color)

    # 跟随系统主题：每两秒探一次，用户在系统里切了深浅色能自己跟上
    if state["frame"] % 120 == 0 and cfg_get("theme_mode", "auto") == "auto":
        want = theme.resolve("auto")
        if want != theme.key():
            theme.apply(want)
            refresh_view()
