# -*- coding: utf-8 -*-
"""theme.py —— 配色、字体、图标、主题对象。

改样式之前先读这五条：

1. 灰阶是中性灰（不带黄），强调色只出现在两处：
   「当前选中的世界」和「主动作按钮」。其它一切靠字号、字重、留白分层。
2. 暗色不用纯黑。太黑会让深色界面像一块洞，眼睛累；这里从 #1B1D21 起，
   靠四层 elevation（bg → rail → card → raise）拉开层次。
3. 字体只有三个尺寸：display（base+4）/ body（base）/ meta（base-3），
   比例约 1.25。区块标题跟正文同尺寸，只换字体家族（等线 Bold），
   靠家族和字重区分层级，比"再大一号"更克制。
4. 图标用系统自带的 Segoe Fluent Icons（Win11 一定有，不用装 nerd font）。
   DPG 一个控件只能挂一种字体，所以图标按钮只能做纯图标，带字的按钮保留文字。
5. 所有带内边距的 child window 必须 border=True，边框色设成和底色相同。
   原因见 child_theme() 的注释——DPG 的坑。

字体/字号/配色一变，整个界面要重建（见 pages.rebuild_all）。
"""
import os

import dearpygui.dearpygui as dpg

# ---------------- 基础尺寸 ----------------
# 只给三档。每档都要生成字体图集，档位多了启动慢且没有实际意义。
FONT_SIZE_CHOICES = [14, 16, 18]
FONT_SIZE_LABELS = {14: "小", 16: "标准", 18: "大"}
DEFAULT_FONT_SIZE = 16

# ---------------- 图标 ----------------
# Segoe Fluent Icons 的码位（Win11 自带）。Win10 的 segmdl2.ttf 大部分码位相同，
# 这两个文件按顺序探测，谁在就用谁。
ICON_FILES = ("SegoeIcons.ttf", "segmdl2.ttf")

ICONS = {
    "min": "\uE921",
    "max": "\uE922",
    "restore_window": "\uE923",
    "close": "\uE8BB",
    "settings": "\uE713",
    "refresh": "\uE72C",
    "folder": "\uE8B7",
    "trash": "\uE74D",
    "history": "\uE81C",
    "sync": "\uE895",
    "add": "\uE710",
    "library": "\uE8F1",
    "save": "\uE74E",
}

# ---------------- 灰阶（两套，全是中性灰，不带色相） ----------------
# 暗色：四层 elevation，最底不是纯黑而是 #1B1D21
DARK = {
    "bg":        (27, 29, 33, 255),    # #1B1D21  窗口底
    "rail":      (33, 36, 41, 255),    # #212429  标题栏 / 状态栏 / 世界栏
    "card":      (39, 43, 49, 255),    # #272B31  卡片、选中行、输入框
    "raise":     (49, 53, 60, 255),    # #31353C  悬停
    "line":      (58, 63, 71, 255),    # #3A3F47  分隔线
    "text":      (233, 235, 238, 255),  # #E9EBEE
    "text2":     (167, 174, 184, 255),  # #A7AEB8
    "text3":     (134, 141, 152, 255),  # #868D98
    "danger":    (208, 87, 74, 255),    # #D0574A
    "danger_hi": (224, 106, 92, 255),
    "close_hi":  (196, 43, 28, 255),    # Windows 原生关闭按钮红
}

# 亮色：纸感白，但依然是中性灰，不偏米黄
LIGHT = {
    "bg":        (247, 248, 250, 255),  # #F7F8FA
    "rail":      (238, 240, 243, 255),  # #EEF0F3
    "card":      (255, 255, 255, 255),  # #FFFFFF
    "raise":     (229, 232, 237, 255),  # #E5E8ED
    "line":      (214, 218, 224, 255),  # #D6DAE0
    "text":      (28, 31, 36, 255),     # #1C1F24
    "text2":     (92, 99, 109, 255),    # #5C636D
    "text3":     (101, 108, 118, 255),  # #656C76
    "danger":    (178, 58, 44, 255),    # #B23A2C
    "danger_hi": (198, 74, 58, 255),
    "close_hi":  (196, 43, 28, 255),
}

# ---------------- 强调色方案 ----------------
# 每套只换三个值：常态 / 悬停 / 按下。灰阶不动，
# 所以换配色不会破坏整体气质，只是换了一种"灯光的颜色"。
ACCENTS = {
    "ember": {
        "label": "火橙",
        "dark": ((224, 130, 52), (240, 160, 85), (168, 94, 34)),
        "light": ((180, 85, 26), (201, 103, 31), (143, 68, 19)),
    },
    "azure": {
        "label": "靛蓝",
        "dark": ((78, 143, 214), (107, 166, 232), (52, 104, 160)),
        "light": ((47, 111, 181), (63, 132, 205), (33, 85, 143)),
    },
    "moss": {
        "label": "苔绿",
        "dark": ((92, 158, 107), (116, 182, 131), (66, 120, 79)),
        "light": ((63, 122, 78), (78, 145, 94), (45, 94, 58)),
    },
    "plum": {
        "label": "紫檀",
        "dark": ((169, 123, 196), (190, 146, 214), (128, 88, 152)),
        "light": ((123, 90, 150), (144, 108, 172), (98, 68, 122)),
    },
}
DEFAULT_ACCENT = "ember"

# 强调色上的文字。原则：字色永远是强调色的反色——
# 暗色主题的强调色偏亮，所以配近黑字；亮色主题的强调色偏深，所以配近白字。
# 这样四套配色的对比度都在 4.5:1 以上（白字压橙底只有 2.7:1，不达标）。
ON_ACCENT_DARK = (22, 23, 26, 255)
ON_ACCENT_LIGHT = (255, 253, 250, 255)

_font_dir = os.path.join(os.environ.get("WINDIR", r"C:\Windows"), "Fonts")
UI_FONT_FILE = os.path.join(_font_dir, "msyh.ttc")      # 微软雅黑：正文
TITLE_FONT_FILE = os.path.join(_font_dir, "Dengb.ttf")  # 等线 Bold：标题

_fonts = {}        # (family, size) -> 字体 id
_theme_key = "dark"
_accent_key = DEFAULT_ACCENT
_themes = {}       # 名字 -> 主题 id
_palette = {}
_font_size = DEFAULT_FONT_SIZE


# ---------------- 字体 ----------------

def _icon_file():
    for name in ICON_FILES:
        path = os.path.join(_font_dir, name)
        if os.path.isfile(path):
            return path
    return None


def build_fonts():
    """只为实际会用到的字号生成字体，避免启动时编译几十个大字体图集。"""
    body_sizes = {s for base in FONT_SIZE_CHOICES for s in (base, base - 3)}
    title_sizes = {s for base in FONT_SIZE_CHOICES for s in (base + 4,)}
    icon_sizes = {s for base in FONT_SIZE_CHOICES for s in (base + 2, base - 3)}
    icon_path = _icon_file()

    with dpg.font_registry():
        for size in sorted(body_sizes):
            _fonts[("body", size)] = dpg.add_font(UI_FONT_FILE, size)
        if os.path.isfile(TITLE_FONT_FILE):
            for size in sorted(title_sizes):
                _fonts[("title", size)] = dpg.add_font(TITLE_FONT_FILE, size)
        if icon_path:
            for size in sorted(icon_sizes):
                _fonts[("icon", size)] = dpg.add_font(icon_path, size)


def font(role="body"):
    """按角色取字体。

    display 品牌/页标题（等线 Bold），head 区块标题（等线 Bold，同尺寸），
    body 正文（雅黑），meta 元信息（雅黑，小一号），
    icon 图标（Fluent Icons），icon_small 小图标。
    """
    base = _font_size
    table = {
        "display": ("title", base + 4),
        "head":    ("title", base),
        "body":    ("body", base),
        "meta":    ("body", base - 3),
        "icon":    ("icon", base + 2),
        "icon_small": ("icon", base - 3),
    }
    family, size = table.get(role, table["body"])
    # 字体文件缺失时退回任意一个已加载的字体，界面不会崩
    return (_fonts.get((family, size)) or _fonts.get(("body", base))
            or next(iter(_fonts.values())))


def has_icons():
    return any(key[0] == "icon" for key in _fonts)


def font_size():
    return _font_size


def set_font_size(size):
    global _font_size
    if int(size) in FONT_SIZE_CHOICES:
        _font_size = int(size)


def font_size_label():
    return FONT_SIZE_LABELS.get(_font_size, "标准")


# ---------------- 主题对象 ----------------

def _make(colors, mapping, styles=(), target=dpg.mvAll):
    """按 {ImGui 颜色常量: 调色板键} 生成一个主题。

    DPG 2.3 的签名是 add_theme_color(常量, 颜色, category=...)，
    和网上老教程的 (category, 常量, 颜色) 顺序不同，别照抄。
    """
    with dpg.theme() as theme_id:
        with dpg.theme_component(target):
            for col, key in mapping.items():
                value = colors.get(key, key) if isinstance(key, str) else key
                dpg.add_theme_color(col, value, category=dpg.mvThemeCat_Core)
            for var, val in styles:
                if isinstance(val, (tuple, list)):
                    dpg.add_theme_style(var, val[0], val[1], category=dpg.mvThemeCat_Core)
                else:
                    dpg.add_theme_style(var, val, category=dpg.mvThemeCat_Core)
    return theme_id


def child_theme(colors, bg_key, pad=(0, 0), text_key="text"):
    """给一个带内边距的 child window 做主题。

    ⚠ DPG 的坑：border=False 的 child window 会**忽略**主题里的 WindowPadding
    （border=True 才生效）。所以这里统一 border=True，
    再把边框色设成和底色一模一样，肉眼看不见框，但内边距留住了。
    四种组合实测：border=T→生效 / border=F→失效 / border=F+无滚动条→失效 / border=T+无滚动条→生效。
    """
    return _make(colors, {
        dpg.mvThemeCol_ChildBg: bg_key,
        dpg.mvThemeCol_Border: bg_key,     # 边框融进底色
        dpg.mvThemeCol_Text: text_key,
    }, [(dpg.mvStyleVar_WindowPadding, pad)])


# 全局基础样式：圆角克制，间距取 4 的倍数
BASE_STYLES = [
    (dpg.mvStyleVar_FrameRounding, 4),
    (dpg.mvStyleVar_WindowRounding, 8),
    (dpg.mvStyleVar_ChildRounding, 6),
    (dpg.mvStyleVar_PopupRounding, 8),
    (dpg.mvStyleVar_FramePadding, (10, 6)),
    (dpg.mvStyleVar_ItemSpacing, (10, 8)),
    (dpg.mvStyleVar_CellPadding, (8, 4)),
    (dpg.mvStyleVar_WindowPadding, (18, 16)),
    (dpg.mvStyleVar_ScrollbarSize, 10),
]


def _build_one_mode(colors):
    """为一种色调生成整套主题对象，返回 {名字: 主题 id}。

    DPG 的样式是"整块替换"的：给某个控件绑定主题时，
    这个主题里没写的样式会退回 ImGui 默认值，而不是继承全局。
    所以 BASE_STYLES 必须写进 root（全局那个）。
    """
    t = {}

    t["root"] = _make(colors, {
        dpg.mvThemeCol_WindowBg: "bg",
        dpg.mvThemeCol_ChildBg: "bg",
        dpg.mvThemeCol_Text: "text",
        dpg.mvThemeCol_TextDisabled: "text3",
        dpg.mvThemeCol_PopupBg: "card",
        dpg.mvThemeCol_Border: "line",
        dpg.mvThemeCol_Separator: "line",
        dpg.mvThemeCol_ScrollbarBg: "bg",
        dpg.mvThemeCol_ScrollbarGrab: "line",
        dpg.mvThemeCol_ScrollbarGrabHovered: "raise",
        dpg.mvThemeCol_ScrollbarGrabActive: "raise",
        dpg.mvThemeCol_CheckMark: "accent",
        dpg.mvThemeCol_SliderGrab: "accent",
        dpg.mvThemeCol_ModalWindowDimBg: (0, 0, 0, 150),
        # 下面这些必须写进全局主题：没写的话，任何"忘了单独绑主题"的
        # 输入框/下拉框/按钮都会退回 ImGui 自带的深色默认值，
        # 在亮色主题下就是一块突兀的黑方块。
        dpg.mvThemeCol_FrameBg: "card",
        dpg.mvThemeCol_FrameBgHovered: "raise",
        dpg.mvThemeCol_FrameBgActive: "raise",
        dpg.mvThemeCol_Button: "raise",
        dpg.mvThemeCol_ButtonHovered: "line",
        dpg.mvThemeCol_ButtonActive: "line",
        dpg.mvThemeCol_Header: "card",
        dpg.mvThemeCol_HeaderHovered: "raise",
        dpg.mvThemeCol_HeaderActive: "raise",
        dpg.mvThemeCol_ResizeGrip: "line",
        dpg.mvThemeCol_Tab: "raise",
        dpg.mvThemeCol_TabHovered: "line",
        dpg.mvThemeCol_TabActive: "card",
    }, BASE_STYLES + [(dpg.mvStyleVar_WindowPadding, (0, 0))])

    # 输入框、下拉框
    t["frame"] = _make(colors, {
        dpg.mvThemeCol_FrameBg: "card",
        dpg.mvThemeCol_FrameBgHovered: "raise",
        dpg.mvThemeCol_FrameBgActive: "raise",
        dpg.mvThemeCol_Text: "text",
        dpg.mvThemeCol_CheckMark: "accent",
    })

    # 普通按钮：中性，绝不抢主动作的强调色
    t["button"] = _make(colors, {
        dpg.mvThemeCol_Button: "raise",
        dpg.mvThemeCol_ButtonHovered: "line",
        dpg.mvThemeCol_ButtonActive: "line",
        dpg.mvThemeCol_Text: "text",
    }, target=dpg.mvButton)

    # 主动作：全界面唯一一块强调色
    t["primary"] = _make(colors, {
        dpg.mvThemeCol_Button: "accent",
        dpg.mvThemeCol_ButtonHovered: "accent_hi",
        dpg.mvThemeCol_ButtonActive: "accent_lo",
        dpg.mvThemeCol_Text: "on_accent",
    }, target=dpg.mvButton)

    # 幽灵按钮：无底，悬停才浮起来。用于行内操作
    t["ghost"] = _make(colors, {
        dpg.mvThemeCol_Button: (0, 0, 0, 0),
        dpg.mvThemeCol_ButtonHovered: "raise",
        dpg.mvThemeCol_ButtonActive: "line",
        dpg.mvThemeCol_Text: "text2",
    }, target=dpg.mvButton)

    t["ghost_danger"] = _make(colors, {
        dpg.mvThemeCol_Button: (0, 0, 0, 0),
        dpg.mvThemeCol_ButtonHovered: "danger",
        dpg.mvThemeCol_ButtonActive: "danger_hi",
        dpg.mvThemeCol_Text: "text2",
    }, target=dpg.mvButton)

    # 窗口外壳：标题栏和状态栏同底色，读起来像"同一个框架"
    t["titlebar"] = _make(colors, {
        dpg.mvThemeCol_ChildBg: "rail",
        dpg.mvThemeCol_Border: "rail",
        dpg.mvThemeCol_Text: "text2",
    }, [(dpg.mvStyleVar_WindowPadding, (0, 0)),
        # 归零：三个窗口按钮必须彼此紧贴、贴齐右上角
        (dpg.mvStyleVar_ItemSpacing, (0, 0))])
    # 标题栏左侧那块（品牌 + 导航）自己用正常间距
    t["brandbar"] = _make(colors, {
        dpg.mvThemeCol_ChildBg: "rail",
        dpg.mvThemeCol_Border: "rail",
        dpg.mvThemeCol_Text: "text2",
    }, [(dpg.mvStyleVar_WindowPadding, (0, 0)),
        (dpg.mvStyleVar_ItemSpacing, (10, 8))])
    t["statusbar"] = child_theme(colors, "rail", (20, 0), "text3")
    # 世界栏：一整块深一层的底，和右侧内容区分开
    t["rail"] = child_theme(colors, "rail", (16, 14))
    # 主区域
    t["main"] = child_theme(colors, "bg", (26, 16))
    # 工具条：左右和主区域对齐
    t["toolbar"] = child_theme(colors, "bg", (26, 0))
    # 纯容器：不要内边距，内容自己控制
    t["body"] = child_theme(colors, "bg", (0, 0))

    # 标题栏里的排版表：单元格不要内边距，靠显式 spacer 控制间距，
    # 这样右上角的窗口按钮才能贴齐窗口边缘（像原生程序那样）
    t["chrome_table"] = _make(colors, {
        dpg.mvThemeCol_ChildBg: "rail",
    }, [(dpg.mvStyleVar_CellPadding, (0, 0))])

    # 导航：选中 = 强调色文字，未选中 = 次要灰。没有色块，克制
    t["nav_on"] = _make(colors, {
        dpg.mvThemeCol_Button: (0, 0, 0, 0),
        dpg.mvThemeCol_ButtonHovered: "raise",
        dpg.mvThemeCol_ButtonActive: "raise",
        dpg.mvThemeCol_Text: "accent",
    }, target=dpg.mvButton)

    t["nav_off"] = t["ghost"]

    # 窗口按钮：无圆角、无底色，悬停才亮；关闭按钮悬停是系统红
    t["winbtn"] = _make(colors, {
        dpg.mvThemeCol_Button: (0, 0, 0, 0),
        dpg.mvThemeCol_ButtonHovered: "raise",
        dpg.mvThemeCol_ButtonActive: "line",
        dpg.mvThemeCol_Text: "text2",
    }, [(dpg.mvStyleVar_FrameRounding, 0)], target=dpg.mvButton)

    t["winbtn_close"] = _make(colors, {
        dpg.mvThemeCol_Button: (0, 0, 0, 0),
        dpg.mvThemeCol_ButtonHovered: "close_hi",
        dpg.mvThemeCol_ButtonActive: "close_hi",
        dpg.mvThemeCol_Text: "text2",
    }, [(dpg.mvStyleVar_FrameRounding, 0)], target=dpg.mvButton)

    # 世界栏的一行（selectable）：选中 = 卡片底 + 强调色文字
    t["row_on"] = _make(colors, {
        dpg.mvThemeCol_Header: "card",
        dpg.mvThemeCol_HeaderHovered: "card",
        dpg.mvThemeCol_HeaderActive: "card",
        dpg.mvThemeCol_Text: "accent",
    })
    t["row_off"] = _make(colors, {
        dpg.mvThemeCol_Header: (0, 0, 0, 0),
        dpg.mvThemeCol_HeaderHovered: "card",
        dpg.mvThemeCol_HeaderActive: "card",
        dpg.mvThemeCol_Text: "text2",
    })

    # 表格：只要留白，不要网格线（网格会让它像 Excel 而不是时间轴）
    t["table"] = _make(colors, {
        dpg.mvThemeCol_TableRowBg: (0, 0, 0, 0),
        dpg.mvThemeCol_TableRowBgAlt: (0, 0, 0, 0),
        dpg.mvThemeCol_TableBorderStrong: "line",
        dpg.mvThemeCol_TableBorderLight: "line",
        dpg.mvThemeCol_Header: (0, 0, 0, 0),
        dpg.mvThemeCol_HeaderHovered: "card",
        dpg.mvThemeCol_HeaderActive: "card",
        dpg.mvThemeCol_Text: "text",
    })

    # 弹窗：需要内边距，且独立于 root 的 0 内边距
    t["modal"] = _make(colors, {
        dpg.mvThemeCol_WindowBg: "card",
        dpg.mvThemeCol_Text: "text",
        dpg.mvThemeCol_Border: "line",
        dpg.mvThemeCol_TitleBg: "rail",
        dpg.mvThemeCol_TitleBgActive: "rail",
        dpg.mvThemeCol_Separator: "line",
        dpg.mvThemeCol_PopupBg: "card",
    }, [(dpg.mvStyleVar_WindowPadding, (22, 18))])

    return t


def _palette_for(base, accent_key, mode):
    """把灰阶和强调色拼成一份完整调色板。"""
    accent, accent_hi, accent_lo = ACCENTS[accent_key][mode]
    palette = dict(base)
    palette["accent"] = accent + (255,)
    palette["accent_hi"] = accent_hi + (255,)
    palette["accent_lo"] = accent_lo + (255,)
    palette["on_accent"] = ON_ACCENT_DARK if mode == "dark" else ON_ACCENT_LIGHT
    return palette


def build_themes(accent_key=DEFAULT_ACCENT):
    """只为当前选中的强调色生成主题（明暗各一套），不预生成全部配色。"""
    global _themes, _accent_key
    _accent_key = accent_key if accent_key in ACCENTS else DEFAULT_ACCENT
    _themes = {
        "dark": _build_one_mode(_palette_for(DARK, _accent_key, "dark")),
        "light": _build_one_mode(_palette_for(LIGHT, _accent_key, "light")),
    }


def colors():
    if not _palette:
        return _palette_for(DARK if _theme_key == "dark" else LIGHT, _accent_key, _theme_key)
    return _palette


def theme(name):
    """取当前色调下的某个主题对象。name 见 _build_one_mode 里的键名。"""
    return _themes[_theme_key][name]


def paint(item, name):
    """给控件套主题；name 为空则不套。"""
    if item and name:
        dpg.bind_item_theme(item, theme(name))


def accent_key():
    return _accent_key


# ---------------- 应用主题 ----------------

def system_prefers_light():
    try:
        import winreg
        with winreg.OpenKey(
            winreg.HKEY_CURRENT_USER,
            r"Software\Microsoft\Windows\CurrentVersion\Themes\Personalize",
        ) as key:
            value, _ = winreg.QueryValueEx(key, "AppsUseLightTheme")
            return bool(value)
    except OSError:
        return False


def resolve(mode):
    """把 auto/dark/light 解析成实际生效的 dark/light。"""
    if mode == "auto":
        return "light" if system_prefers_light() else "dark"
    return "light" if mode == "light" else "dark"


def apply(key):
    """切换全局色调。调用方负责在之后重建界面。"""
    global _theme_key, _palette
    _theme_key = key
    _palette = _palette_for(DARK if key == "dark" else LIGHT, _accent_key, key)
    dpg.bind_theme(_themes[key]["root"])
    dpg.bind_font(font("body"))
    from widgets import sync_window_chrome
    sync_window_chrome(key == "dark")


def key():
    return _theme_key
