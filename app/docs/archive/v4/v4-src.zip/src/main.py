# -*- coding: utf-8 -*-
"""main.py —— 程序入口。

启动顺序有一个关键点：窗口是无边框的（decorated=False），
所以位置必须在建视口时就算好并传入，否则会先在屏幕左上角闪一下再跳过来。
"""
import os
import sys
import time

import dearpygui.dearpygui as dpg

import app
import backup_core as bc
import pages
import theme
import widgets
from widgets import TAGS

VIEW_W, VIEW_H = 1080, 760

_tray_icon = None


def _centered_pos():
    left, top, width, height = widgets.work_area()
    return [left + max(0, (width - VIEW_W) // 2), top + max(0, (height - VIEW_H) // 2) - 16]


def _make_tray_image():
    """托盘图标：橙底 + "饥" 字。用 Pillow 现画，省掉一个图片资源文件。"""
    from PIL import Image, ImageDraw, ImageFont
    image = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    draw.rounded_rectangle([4, 4, 60, 60], radius=14, fill=(224, 130, 52, 255))
    try:
        font = ImageFont.truetype(os.path.join(os.environ.get("WINDIR", r"C:\Windows"),
                                               "Fonts", "msyhbd.ttc"), 34)
        draw.text((32, 33), "饥", font=font, fill=(255, 246, 232, 255), anchor="mm")
    except Exception:
        draw.ellipse([20, 20, 44, 44], fill=(255, 246, 232, 255))
    return image


def setup_tray():
    global _tray_icon
    try:
        import pystray

        def on_show(icon, item):
            widgets.restore()

        def on_exit(icon, item):
            app.state["quit"] = True
            icon.stop()

        menu = pystray.Menu(
            pystray.MenuItem("显示主窗口", on_show, default=True),
            pystray.MenuItem("退出", on_exit),
        )
        _tray_icon = pystray.Icon("dst-saver", _make_tray_image(), pages.APP_TITLE, menu)
        _tray_icon.run_detached()
    except Exception as e:
        print("托盘初始化失败:", e)


def main():
    dpg.create_context()

    theme.build_fonts()
    theme.build_themes(app.cfg_get("accent", theme.DEFAULT_ACCENT))
    theme.set_font_size(app.cfg_get("font_size", theme.DEFAULT_FONT_SIZE))
    theme.apply(theme.resolve(app.cfg_get("theme_mode", "auto")))

    pos = _centered_pos()
    bg = theme.colors()["bg"]
    dpg.create_viewport(
        title=pages.APP_TITLE,
        width=VIEW_W, height=VIEW_H,
        x_pos=pos[0], y_pos=pos[1],
        decorated=False,      # 自绘标题栏，见 pages._build_titlebar
        resizable=False,      # 无边框窗口没有系统缩放边，固定尺寸最稳
        vsync=True,
        # 开发用：设了 DST_ONTOP=1 就置顶，方便截图（打包运行时不需要）
        always_on_top=bool(os.environ.get("DST_ONTOP")),
        clear_color=[bg[0] / 255, bg[1] / 255, bg[2] / 255, 1.0],
    )
    dpg.setup_dearpygui()

    # 根窗口不放进 with 里：这样 pages.build() 里创建弹窗时没有活动容器，
    # 弹窗才会是顶层窗口而不是根窗口的子项
    dpg.add_window(tag=TAGS["root"], no_title_bar=True, no_scrollbar=True,
                   no_move=True, no_resize=True, no_collapse=True)
    pages.build()

    dpg.set_primary_window(TAGS["root"], True)
    dpg.show_viewport()
    if os.environ.get("DST_ONTOP"):
        dpg.set_viewport_always_top(True)

    setup_tray()
    app.start_watcher()

    # 备份目录不存在就建出来（软件自管，首次运行才有这一步）
    try:
        os.makedirs(app.backup_root(), exist_ok=True)
    except OSError:
        pass

    dirs = bc.locate_save_dirs()
    if dirs:
        app.load_worlds(dirs[0] if not app.cfg_get("save_dir") else app.cfg_get("save_dir"))
    else:
        app.set_status("没有找到饥荒存档目录，点「浏览…」手动指定", error=True)

    # 开发用：DST_SHOT=路径 时，跑够 45 帧就导出自己的帧缓冲再退出。
    # 截图不依赖窗口是否被遮挡，也不会去操作别人的窗口。
    shot_path = os.environ.get("DST_SHOT")
    chrome_ready = False
    title_watchdog = 0
    while dpg.is_dearpygui_running() and not app.state["quit"]:
        if not chrome_ready:
            chrome_ready = widgets.apply_window_chrome(
                pages.APP_TITLE, theme.key() == "dark", app.on_close_request)
        elif title_watchdog < 20:
            # 头 20 帧盯着标题，DPG 中途覆盖就再改回来
            title_watchdog += 1
            widgets.ensure_title(pages.APP_TITLE)
        app.on_frame()
        dpg.render_dearpygui_frame()
        if shot_path and app.state["frame"] >= 45:
            # 导出是排到下一帧执行的，所以拍完还要多跑几帧再退出
            dpg.output_frame_buffer(shot_path)
            shot_path = None
            app.state["shot_deadline"] = app.state["frame"] + 12
        if app.state.get("shot_deadline") and app.state["frame"] > app.state["shot_deadline"]:
            break

    if _tray_icon:
        try:
            _tray_icon.stop()
        except Exception:
            pass
    dpg.destroy_context()


if __name__ == "__main__":
    main()
