# -*- coding: utf-8 -*-
"""pages.py —— 界面骨架（标题栏 / 工具条 / 世界栏 / 主区域 / 状态栏 / 弹窗）。

这个文件只负责"摆在哪"和"长什么样"，不处理业务；
所有带业务含义的按钮回调都指向 app.py 里的函数。

窗口是无边框的（decorated=False），所以标题栏、最小化、最大化、关闭
都是自己画的，拖动逻辑在 widgets.tick_drag。
"""
import dearpygui.dearpygui as dpg
from contextlib import contextmanager

import app
import backup_core as bc
import theme
import widgets
from widgets import TAGS

APP_TITLE = "饥荒单机存档备份工具"
BRAND = "饥荒存档备份"
VERSION = "v4.0"


# ---------------- 入口 ----------------

def build():
    """从零搭出整个界面。主题或字号变化时整块重建，见 rebuild_all。"""
    _build_titlebar()
    _build_toolbar()
    _build_body()
    _build_statusbar()
    _build_modals()
    _build_dialogs()

    # 静态骨架好了，再把动态内容填进去
    app.render_rail()
    app.render_rail_footer()
    app.render_detail()

    app.bind_render(rebuild_all, render_settings)


def rebuild_all():
    """删掉 root 的所有子项重画。主题、字号一变就走这条路，最不容易漏。"""
    dpg.delete_item(TAGS["root"], children_only=True)
    for tag in ("modal_close", "modal_restore", "modal_delete",
                "dlg_save_dir", "dlg_backup_root"):
        if dpg.does_item_exist(tag):
            dpg.delete_item(tag)
    build()


# ---------------- 标题栏 ----------------

def _centered(font_px, builder, bar=widgets.TITLEBAR_H):
    """把一项内容放进标题栏并垂直居中。

    DPG 没有 vertical-align：同一行里的元素全部顶端对齐，
    所以只能让每一项各自套一个竖向 group，前面补 (条高-字号)/2 的空白。
    这样字号不同的文字、图标、按钮，视觉中线才会落在同一条线上。
    """
    with dpg.group():
        dpg.add_spacer(height=max(0, (bar - font_px) // 2))
        builder()


def _build_titlebar():
    base = theme.font_size()

    # 显式指定 parent：重建界面时容器栈是空的，靠隐式父级会报 "Parent could not be deduced"
    with dpg.child_window(tag=TAGS["titlebar"], parent=TAGS["root"],
                          height=widgets.TITLEBAR_H, border=True, no_scrollbar=True):
        with dpg.group(horizontal=True):
            # 左边这块吃掉"剩余宽度 - 三个窗口按钮"，于是按钮被顶到最右边贴齐边缘。
            # 负宽度 = 父宽 - N，正是这里需要的弹性布局。
            with dpg.child_window(tag="brandbar", width=-widgets.TITLEBAR_H * 3,
                                  height=-1, border=True, no_scrollbar=True):
                with dpg.group(horizontal=True):
                    dpg.add_spacer(width=16)
                    _centered(base + 2, lambda: widgets.icon("library", role="icon",
                                                             color_key="accent"))
                    dpg.add_spacer(width=10)
                    _centered(base + 4, lambda: widgets.text(BRAND, role="display"))
                    dpg.add_spacer(width=26)
                    _centered(base - 3, lambda: widgets.text("Don't Starve Saver",
                                                             role="meta", color_key="text3"))
                    dpg.add_spacer(width=36)
                    _centered(30, lambda: _nav_row())
            with dpg.group(horizontal=True):
                _window_buttons()

    theme.paint(TAGS["titlebar"], "titlebar")
    theme.paint("brandbar", "brandbar")


def _nav_row():
    with dpg.group(horizontal=True):
        _nav_button("备份", "backup", TAGS["nav_backup"])
        dpg.add_spacer(width=4)
        _nav_button("设置", "settings", TAGS["nav_settings"])


def _nav_button(label, page, tag):
    item = dpg.add_button(label=f"  {label}  ", tag=tag, width=62, height=30,
                          callback=lambda: app.switch_page(page))
    dpg.bind_item_font(item, theme.font("body"))
    theme.paint(item, "nav_on" if app.state["page"] == page else "nav_off")
    return item


def _window_buttons():
    """三个窗口按钮：正方形、无圆角、彼此紧贴、贴齐右上角——和 Windows 原生一致。"""
    size = widgets.TITLEBAR_H
    # 万一系统既没有 SegoeIcons 也没有 segmdl2，退回几何符号，别显示成空白按钮
    fallback = {"min": "—", "max": "□", "close": "×"}
    for name, tag, callback, theme_name in (
        ("min", TAGS["win_min"], widgets.minimize, "winbtn"),
        ("max", TAGS["win_max"], widgets.toggle_maximize, "winbtn"),
        ("close", TAGS["win_close"], app.on_close_request, "winbtn_close"),
    ):
        label = theme.ICONS.get(name, "") if theme.has_icons() else fallback[name]
        item = dpg.add_button(label=label, tag=tag,
                              width=size, height=size, callback=callback)
        dpg.bind_item_font(item, theme.font("icon_small" if theme.has_icons() else "body"))
        theme.paint(item, theme_name)


# ---------------- 工具条 ----------------

def _build_toolbar():
    dirs = bc.locate_save_dirs()
    current = app.state["save_dir"] or app.cfg_get("save_dir", dirs[0] if dirs else "")

    with dpg.child_window(tag=TAGS["toolbar"], parent=TAGS["root"],
                          height=widgets.TOOLBAR_H, border=True, no_scrollbar=True,
                          show=(app.state["page"] == "backup")):
        dpg.add_spacer(height=12)
        with dpg.table(header_row=False, width=-1, policy=dpg.mvTable_SizingStretchProp,
                       borders_innerH=False, borders_outerH=False,
                       borders_innerV=False, borders_outerV=False, pad_outerX=False):
            dpg.add_table_column(width_fixed=True, init_width_or_weight=64)
            dpg.add_table_column(init_width_or_weight=1.0, width_stretch=True)
            dpg.add_table_column(width_fixed=True, init_width_or_weight=84)
            dpg.add_table_column(width_fixed=True, init_width_or_weight=142)

            with dpg.table_row():
                widgets.text("存档目录", role="meta", color_key="text2")
                combo = dpg.add_combo(dirs, default_value=current, width=-1,
                                      tag=TAGS["combo_dir"], callback=_on_dir_changed)
                dpg.bind_item_font(combo, theme.font("meta"))
                with dpg.group(horizontal=True):
                    widgets.icon_button("folder", lambda: dpg.show_item("dlg_save_dir"),
                                        width=34, height=30)
                    dpg.add_spacer(width=4)
                    widgets.icon_button("refresh", app.load_worlds, width=34, height=30)
                with dpg.group(horizontal=True):
                    _auto_toggle()

    theme.paint(TAGS["toolbar"], "toolbar")


def _small_button(label, callback, width=0):
    kwargs = {"label": label, "callback": callback}
    if width:
        kwargs["width"] = width
    item = dpg.add_button(**kwargs)
    dpg.bind_item_font(item, theme.font("meta"))
    theme.paint(item, "button")
    return item


def _auto_toggle():
    """自动备份开关。放在工具条而不是设置页 —— 它是会变的状态，不是配置项。"""
    on = app.state["auto_on"]
    item = dpg.add_button(label=("自动备份 · 开" if on else "自动备份 · 关"),
                          tag=TAGS["auto_btn"], width=132, height=26,
                          callback=_toggle_auto)
    dpg.bind_item_font(item, theme.font("meta"))
    if on:
        theme.paint(item, "nav_on")
    else:
        theme.paint(item, "button")
    return item


def _toggle_auto():
    app.state["auto_on"] = not app.state["auto_on"]
    app.cfg["auto_backup"] = app.state["auto_on"]
    bc.save_config(app.cfg)
    item = TAGS["auto_btn"]
    dpg.configure_item(item, label=("自动备份 · 开" if app.state["auto_on"] else "自动备份 · 关"))
    theme.paint(item, "nav_on" if app.state["auto_on"] else "button")
    app.set_status("自动备份已开启" if app.state["auto_on"] else "自动备份已关闭")


def _on_dir_changed():
    app.load_worlds(dpg.get_value(TAGS["combo_dir"]))


# ---------------- 主体 ----------------

def _build_body():
    with dpg.child_window(tag=TAGS["body"], parent=TAGS["root"],
                          height=-(widgets.STATUSBAR_H + widgets.GAP), border=True, no_scrollbar=True):
        with dpg.group(horizontal=True):
            # 设置页不放世界栏：那是备份页的上下文，留在这里只会白占 320px
            if app.state["page"] == "backup":
                _build_rail()
            _build_main()


def _build_rail():
    """世界栏：左侧常驻。选中世界 + 全局统计都在这，不必再开一个面板。"""
    with dpg.child_window(tag=TAGS["rail"], width=widgets.RAIL_W, height=-1,
                          border=True, no_scrollbar=True):
        with dpg.group(tag=TAGS["rail_head"], horizontal=True):
            widgets.text("世界", role="head", color_key="text")
            dpg.add_spacer(width=6)
            widgets.hint(f"{len(app.state['worlds'])} 个")
        dpg.add_spacer(height=8)

        dpg.add_child_window(tag=TAGS["rail_list"], width=-1, height=-52,
                             border=False, no_scrollbar=False)

        with dpg.group(tag=TAGS["rail_foot"]):
            pass
    theme.paint(TAGS["rail"], "rail")


def _build_main():
    with dpg.child_window(tag=TAGS["main"], width=-1, height=-1, border=True,
                          no_scrollbar=False):
        # 内容区整体可滚动：备份多了往下翻，设置页也不会被裁掉
        dpg.add_child_window(tag=TAGS["main_body"], width=-1, height=-1,
                             border=False, no_scrollbar=False)
    theme.paint(TAGS["main"], "main")


# ---------------- 状态栏 ----------------

def _build_statusbar():
    with dpg.child_window(tag="statusbar", parent=TAGS["root"],
                          height=widgets.STATUSBAR_H, border=True, no_scrollbar=True):
        with dpg.group(horizontal=True):
            widgets.text("就绪", role="meta", color_key="text3", tag=TAGS["status_text"])
    theme.paint("statusbar", "statusbar")


def render_settings(container):
    """设置页：每个区块 = 一个小标题 + 一张独立表单表。

    不共用一张大表，是因为 DPG 里同一张表只能连续往下画，
    中间插标题会把渲染顺序搞乱；多建几张表、列宽保持一致就行。
    """
    with dpg.group(parent=container):
        info = bc.stats(app.backup_root())

        # 主动作固定放右上角：内容和窗口高度怎么变，它都不会被挤到屏幕外
        with dpg.table(header_row=False, width=-1,
                       policy=dpg.mvTable_SizingStretchProp,
                       borders_innerH=False, borders_outerH=False,
                       borders_innerV=False, borders_outerV=False, pad_outerX=False):
            dpg.add_table_column(init_width_or_weight=1.0, width_stretch=True)
            dpg.add_table_column(width_fixed=True, init_width_or_weight=112)
            with dpg.table_row():
                widgets.text("设置", role="display")
                widgets.primary_button("保存设置", app.on_save_settings, width=104, height=32)
        dpg.add_spacer(height=6)

        widgets.section("外观")
        dpg.add_spacer(height=4)
        grid = _form_table("grid_look")
        _form_row(grid, "主题模式",
                  lambda: dpg.add_combo(list(app.THEME_OPTIONS.values()),
                                        default_value=app.THEME_OPTIONS[app.cfg_get("theme_mode", "auto")],
                                        width=150, tag="set_theme"),
                  "跟随系统会自动匹配 Windows 深浅色")
        _form_row(grid, "强调色",
                  lambda: dpg.add_combo([v["label"] for v in theme.ACCENTS.values()],
                                        default_value=theme.ACCENTS[theme.accent_key()]["label"],
                                        width=150, tag="set_accent"),
                  "只用于「当前选中的世界」和主动作按钮")
        _form_row(grid, "界面字号",
                  lambda: dpg.add_combo([theme.FONT_SIZE_LABELS[s] for s in theme.FONT_SIZE_CHOICES],
                                        default_value=theme.font_size_label(),
                                        width=150, tag="set_font"),
                  "标题与辅助文字自动联动")

        dpg.add_spacer(height=3)
        widgets.section("备份")
        dpg.add_spacer(height=4)
        grid = _form_table("grid_backup")
        _form_row(grid, "备份目录",
                  lambda: dpg.add_input_text(default_value=app.backup_root(), width=246, tag="set_root"),
                  None,
                  extra=lambda: dpg.add_button(label="浏览…", width=62,
                                               callback=lambda: dpg.show_item("dlg_backup_root")))
        _form_row(grid, "手动保留",
                  lambda: dpg.add_input_int(default_value=app.keep_manual(), width=90, tag="set_keep"),
                  "每个世界保留多少份手动备份，超出自动删最旧")
        _form_row(grid, "自动保留",
                  lambda: dpg.add_input_int(default_value=app.keep_auto(), width=90, tag="set_keep_auto"),
                  "自动备份单独计数，不会挤掉你手动留的")
        _form_row(grid, "自动备份",
                  lambda: dpg.add_checkbox(label="存档变化时自动打快照",
                                           default_value=app.state["auto_on"], tag="set_auto"),
                  f"游戏中每次保存都会触发，同一世界 {app.AUTO_COOLDOWN} 秒内只备一次")
        _form_row(grid, "占用",
                  lambda: _storage_controls(info),
                  "只清理超出份数上限的旧备份，最新几份不动")

        dpg.add_spacer(height=3)
        widgets.section("窗口")
        dpg.add_spacer(height=4)
        grid = _form_table("grid_window")
        _form_row(grid, "关闭按钮",
                  lambda: dpg.add_combo(list(app.CLOSE_OPTIONS.values()),
                                        default_value=app.CLOSE_OPTIONS[app.cfg_get("close_action", "tray")],
                                        width=150, tag="set_close"),
                  None,
                  extra=lambda: dpg.add_button(label="立即隐藏到托盘", width=120,
                                               callback=widgets.minimize))


def _storage_controls(info):
    """存储行：一句占用概览 + 清理按钮，放同一行省高度。"""
    with dpg.group(horizontal=True):
        widgets.text(f"{bc.fmt_size(info['total_bytes'])} · {info['count']} 份备份",
                     role="body", color_key="text")
        dpg.add_spacer(width=10)
        dpg.add_button(label="清理旧备份", width=96, callback=app.on_cleanup)


def _form_table(tag):
    """表单栅格：标签列 96、控件列 400、说明列占剩余。

    用表格而不是手工算 padding —— 改字号时列宽不会跟着错位。
    """
    with dpg.table(tag=tag, header_row=False, width=-1,
                   policy=dpg.mvTable_SizingStretchProp,
                   borders_innerH=False, borders_outerH=False,
                   borders_innerV=False, borders_outerV=False, pad_outerX=False):
        dpg.add_table_column(width_fixed=True, init_width_or_weight=96)
        dpg.add_table_column(width_fixed=True, init_width_or_weight=340)
        dpg.add_table_column(init_width_or_weight=1.0, width_stretch=True)
    return tag


def _form_row(table_tag, label, build_control, note=None, extra=None):
    """一行表单：标签 / 控件 / 说明。extra 是控件右边的附加按钮。"""
    with dpg.table_row(parent=table_tag):
        widgets.text(label, role="body", color_key="text2")
        with dpg.group():
            with dpg.group(horizontal=True):
                build_control()
                if extra:
                    extra()
        if note:
            widgets.hint(note)


# ---------------- 弹窗 ----------------

@contextmanager
def _modal(tag, title, width, height):
    """弹窗上下文：负责开窗、约束尺寸、关窗后统一上主题。

    尺寸用 min_size/max_size 双向锁死 —— DPG 里 no_resize=True 会把窗口压成 0，
    这个坑 v3 时代踩过一次。
    """
    with dpg.window(tag=tag, label=title, show=False, width=width, height=height,
                    modal=True, no_resize=False, no_collapse=True,
                    min_size=[width, height], max_size=[width, height]):
        yield
    theme.paint(tag, "modal")


def _build_modals():
    # 关闭确认
    with _modal("modal_close", "关闭窗口", 470, 206):
        dpg.add_spacer(height=4)
        widgets.text("关闭主窗口时，希望怎么处理？", role="body")
        dpg.add_spacer(height=12)
        remember = dpg.add_checkbox(label="记住我的选择，以后不再询问")
        dpg.add_spacer(height=18)
        with dpg.group(horizontal=True):
            widgets.primary_button("最小化到托盘", lambda: app.confirm_close("tray", remember),
                                   width=136, height=32)
            dpg.add_spacer(width=8)
            _small_button("直接退出", lambda: app.confirm_close("exit", remember), width=104)

    # 恢复确认
    with _modal("modal_restore", "确认恢复", 480, 220):
        dpg.add_spacer(height=4)
        widgets.text("将用这份备份覆盖当前存档。", role="body")
        dpg.add_spacer(height=10)
        widgets.hint("请确认饥荒已经完全退出，否则游戏会拿内存里的进度把它盖回去。")
        widgets.hint("覆盖前会先给当前状态拍一份「恢复前」快照，恢复错了还能回来。")
        dpg.add_spacer(height=18)
        with dpg.group(horizontal=True):
            widgets.primary_button("确认恢复", app.confirm_restore, width=104, height=32)
            dpg.add_spacer(width=8)
            _small_button("取消", lambda: app.close_modal("modal_restore"), width=84)

    # 删除确认
    with _modal("modal_delete", "确认删除", 440, 182):
        dpg.add_spacer(height=4)
        widgets.text("确定永久删除这份备份吗？", role="body")
        dpg.add_spacer(height=10)
        widgets.hint("删除后无法恢复。")
        dpg.add_spacer(height=18)
        with dpg.group(horizontal=True):
            danger = dpg.add_button(label="删除", width=84, height=32, callback=app.confirm_delete)
            dpg.bind_item_font(danger, theme.font("body"))
            theme.paint(danger, "ghost_danger")
            dpg.add_spacer(width=8)
            _small_button("取消", lambda: app.close_modal("modal_delete"), width=84)


def _build_dialogs():
    for tag, callback in (("dlg_save_dir", app.on_pick_dir),
                          ("dlg_backup_root", app.on_pick_root)):
        with dpg.file_dialog(tag=tag, directory_selector=True, width=560, height=380,
                             show=False, callback=callback):
            dpg.add_file_extension(".")
